package currencyConverter;

import java.util.ArrayList;
import java.util.HashMap;

public class Currency {
	private String name;
	private String shortName;
	private HashMap<String, Double> exchangeValues = new HashMap<String, Double>();
	
	// "Currency" Constructor
	public Currency(String nameValue, String shortNameValue) {
		this.name = nameValue;
		this.shortName = shortNameValue;
	}
	
	// Getter for name
	public String getName() {
		return this.name;
	}
	
	// Setter for name
	public void setName(String name) {
		this.name = name;
	}
	
	// Getter for shortName
	public String getShortName() {
		return this.shortName;
	}
	
	// Setter for shortName
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	
	// Getter for exchangeValues
	public HashMap<String, Double> getExchangeValues() {
		return this.exchangeValues;
	}
	
	// Setter for exchangeValues
	public void setExchangeValues(String key, Double value) {
		this.exchangeValues.put(key, value);
	}
	
	// Set default values for a currency
	public void defaultValues() {
		String currency = this.name;
		
		switch (currency) {	
			case "US Dollar":
				this.exchangeValues.put("USD", 1.00);
				this.exchangeValues.put("EUR", 1.02);
				this.exchangeValues.put("GBP", 0.89);
				this.exchangeValues.put("CHF", 1.004);
				this.exchangeValues.put("CNY", 7.21);
				this.exchangeValues.put("JPY", 149.93);
				this.exchangeValues.put("INR", 82.75);
				break;
			case "Euro":
				this.exchangeValues.put("USD", 0.97);
				this.exchangeValues.put("EUR", 1.00);
				this.exchangeValues.put("GBP", 0.71);
				this.exchangeValues.put("CHF", 0.98);
				this.exchangeValues.put("CNY", 7.08);
				this.exchangeValues.put("JPY", 146.75);
				this.exchangeValues.put("INR", 80.95);
				break;
			case "British Pound":
				this.exchangeValues.put("USD", 1.12);
				this.exchangeValues.put("EUR", 1.14);
				this.exchangeValues.put("GBP", 1.00);
				this.exchangeValues.put("CHF", 1.12);
				this.exchangeValues.put("CNY", 8.15);
				this.exchangeValues.put("JPY", 168.53);
				this.exchangeValues.put("INR", 92.97);
				break;
			case "Swiss Franc":
				this.exchangeValues.put("USD", 0.99);
				this.exchangeValues.put("EUR", 1.01);
				this.exchangeValues.put("GBP", 0.88);
				this.exchangeValues.put("CHF", 1.00);
				this.exchangeValues.put("CNY", 7.18);
				this.exchangeValues.put("JPY", 122.84);
				this.exchangeValues.put("INR", 82.48);
				break;
			case "Chinese Yuan Renminbi":
				this.exchangeValues.put("USD", 0.13);
				this.exchangeValues.put("EUR", 0.13);
				this.exchangeValues.put("GBP", 0.12);
				this.exchangeValues.put("CHF", 0.13);
				this.exchangeValues.put("CNY", 1.00);
				this.exchangeValues.put("JPY", 20.78);
				this.exchangeValues.put("INR", 11.46);
				break;
			case "Japanese Yen":
				this.exchangeValues.put("USD", 0.006);
				this.exchangeValues.put("EUR", 0.006);
				this.exchangeValues.put("GBP", 0.005);
				this.exchangeValues.put("CHF", 0.008);
				this.exchangeValues.put("CNY", 0.04);
				this.exchangeValues.put("JPY", 1.000);
				this.exchangeValues.put("INR", 0.55);
				break;
			case "Indian Rupee":
				this.exchangeValues.put("USD", 0.01);
				this.exchangeValues.put("EUR", 0.01);
				this.exchangeValues.put("GBP", 0.01);
				this.exchangeValues.put("CHF", 0.012);
				this.exchangeValues.put("CNY", 0.08);
				this.exchangeValues.put("JPY", 1.81);
				this.exchangeValues.put("INR", 1.00);
				break;
		}
	}
	
	// Initialize currencies
	public static ArrayList<Currency> init() {
		ArrayList<Currency> currencies = new ArrayList<Currency>();
				
		currencies.add( new Currency("US Dollar", "USD") );
		currencies.add( new Currency("Euro", "EUR") );
		currencies.add( new Currency("British Pound", "GBP") );
		currencies.add( new Currency("Swiss Franc", "CHF") );
		currencies.add( new Currency("Chinese Yuan Renminbi", "CNY") );
		currencies.add( new Currency("Japanese Yen", "JPY") );
		currencies.add( new Currency("Indian Rupee", "INR") );
		
		for (Integer i =0; i < currencies.size(); i++) {
			currencies.get(i).defaultValues();
		}		
		
		return currencies;
	}
	
	// Convert a currency to another
	public static Double convert(Double amount, Double exchangeValue) {
		Double price;
		price = amount * exchangeValue;
		price = Math.round(price * 100d) / 100d;
		
		return price;
	}
}